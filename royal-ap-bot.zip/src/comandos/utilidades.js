'use strict';

/** Utilidades: ajuda, painel geral, suporte, status, integrações e regras de plataforma. */

const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  SlashCommandBuilder,
} = require('discord.js');
const config = require('../config');
const { obterConfig, definirConfig } = require('../db');
const filas = require('../servicos/filas');
const partidas = require('../servicos/partidas');
const paineis = require('../servicos/paineis');
const tickets = require('../servicos/tickets');
const { exigirStaff, exigirAdmin, responderPrivado, responderErro } = require('../util/seguranca');
const { embed, embedSucesso, dataBR } = require('../util/embeds');

const comandos = [
  {
    data: new SlashCommandBuilder().setName('ajuda').setDescription('Explica como o bot funciona e todos os comandos'),

    async executar(interaction) {
      const paineisDisponiveis = config.MODOS.map((modo) => `\`/${modo.comando}\``).join(' · ');
      const corpo = [
        '**Como funciona um AP:**',
        '1. A staff publica o painel do modo no canal (ex: `/filasx1mobile`).',
        '2. Você escolhe a **faixa de aposta** no menu e o **tipo de gelo**.',
        '3. Quando o grupo fecha, o bot cria uma **sala privada** só com os jogadores.',
        '4. Um jogador envia a regra; todos confirmam.',
        '5. O **mediador** assume, manda o PIX, confere o pagamento e libera a sala.',
        '6. No fim, o mediador declara o vencedor (ou aplica W.O.).',
        '',
        '**Painéis de AP:**',
        paineisDisponiveis,
        '',
        '**Jogador:** `/perfil` · `/ranking` · `/apostas` · `/convites` · `/ticket`',
        '**Staff:** `/painel_mediador` · `/registrar_pix` · `/pix` · `/vencedor` · `/wo` · `/receita_mediadores` · `/analista`',
        '**Configuração:** `/boombot setticket` (categoria ou canal dos tickets) · `/boombot setlog`',
        '**Atendimento:** `/ticket` (painel temporário, 15s) · `/ticketfixo` (painel fixo, só ADM)',
        '**Nix FF (salas automáticas):** `/nix status` · `/nix criarsala` · `/nix iniciar` · `/nix statussala` · `/nix resultado`',
        '**ADM:** `/painel` · `/anunciar` · `/logs` · `/limpar` · `/blacklist` · `/loja` · `/envio_massa` · `/boombot`',
      ].join('\n');

      return responderPrivado(interaction, {
        embeds: [embed('❓ Central de ajuda · ORG Royal AP', corpo, { cor: config.CORES.principal, rodape: 'ORG Royal AP' })],
      });
    },
  },

  {
    data: new SlashCommandBuilder().setName('painel').setDescription('Painel geral de controle da ORG'),

    async executar(interaction, { db }) {
      if (!(await exigirStaff(interaction))) return;
      const guildId = interaction.guildId;
      const emAndamento = partidas.ativas(db, guildId).length;
      const paineisPublicados = paineis.todos(db, guildId).length;
      const naFila = db.prepare('SELECT COUNT(*) AS total FROM filas WHERE guild_id = ?').get(String(guildId)).total;

      const botoes = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ap:minhasalas').setLabel('Salas ativas').setEmoji('📋').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('ap:ranking').setLabel('Ranking').setEmoji('🏆').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('ap:ajuda').setLabel('Ajuda').setEmoji('❓').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('ap:central').setLabel('Central de atendimento').setEmoji('🎫').setStyle(ButtonStyle.Secondary),
      );

      return responderPrivado(interaction, {
        embeds: [
          embed('🎛️ Painel geral · ORG Royal AP', 'Controle rápido do servidor. Use os botões abaixo.', {
            cor: config.CORES.principal,
            campos: [
              { name: 'Salas em andamento', value: String(emAndamento), inline: true },
              { name: 'Jogadores na fila', value: String(naFila), inline: true },
              { name: 'Painéis publicados', value: `${paineisPublicados}/15`, inline: true },
            ],
            rodape: 'ORG Royal AP',
          }),
        ],
        components: [botoes],
      });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('aux')
      .setDescription('Atalho reservado — o atendimento agora é pelo /ticket'),

    async executar(interaction) {
      // A abertura direta foi desativada de propósito. A função continua guardada
      // em servicos/tickets.js (abrirTicket) para quando precisar de novo.
      return responderPrivado(interaction, {
        content: 'Use o comando `/ticket` para abrir a Central de Atendimento.',
      });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('ticket')
      .setDescription('Abre a Central de Atendimento (painel temporário, só você vê)'),

    async executar(interaction) {
      await responderPrivado(interaction, {
        embeds: [tickets.embedCentral()],
        components: tickets.componentesCentral(),
      });

      // O painel se apaga sozinho em 15 segundos para não poluir o canal.
      const expira = setTimeout(() => {
        // deleteReply nem sempre existe (interação antiga): nunca deixa erro solto.
        Promise.resolve()
          .then(() => interaction.deleteReply())
          .catch(() => {});
      }, 15000);
      if (typeof expira.unref === 'function') expira.unref();
      interaction.__expiraTicket = expira;
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('ticketfixo')
      .setDescription('Publica a Central de Atendimento permanente no canal (só ADM)')
      .addChannelOption((opcao) =>
        opcao
          .setName('canal')
          .setDescription('Canal onde publicar (vazio = este canal)')
          .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
      ),

    async executar(interaction) {
      if (!(await exigirAdmin(interaction, 'Só ADM/Gerente pode publicar a Central de Atendimento fixa.'))) return;

      const escolhido = interaction.options.getChannel('canal');
      const canal = escolhido ?? interaction.channel;
      if (!canal?.isTextBased?.()) {
        return responderErro(interaction, 'Use esse comando em um canal de texto.');
      }

      const mensagem = await canal.send({
        embeds: [tickets.embedCentral()],
        components: tickets.componentesCentral(),
      });
      if (typeof mensagem.pin === 'function') await mensagem.pin().catch(() => {});

      return responderPrivado(interaction, {
        embeds: [
          embedSucesso(
            `Central de Atendimento publicada e fixada em ${canal}.\n` +
              '_Lembre: os canais dos tickets são criados onde estiver `TICKET_DESTINO_ID` no .env_ ' +
              '_(aceita ID de categoria **ou** de canal de texto) ou no que você definir com `/boombot setticket`._',
          ),
        ],
      });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('boombot')
      .setDescription('Status e configurações do bot')
      .addSubcommand((sub) => sub.setName('status').setDescription('Mostra a saúde do bot'))
      .addSubcommand((sub) =>
        sub
          .setName('setlog')
          .setDescription('Define o canal de auditoria')
          .addChannelOption((o) => o.setName('canal').setDescription('Canal de logs').setRequired(true)),
      )
      .addSubcommand((sub) =>
        sub
          .setName('setcategoria')
          .setDescription('Define a categoria das salas de AP')
          .addChannelOption((o) =>
            o
              .setName('categoria')
              .setDescription('Categoria onde as salas serão criadas')
              .setRequired(true)
              .addChannelTypes(ChannelType.GuildCategory),
          ),
      )
      .addSubcommand((sub) =>
        sub
          .setName('setticket')
          .setDescription('Define onde os tickets são criados (categoria OU canal de texto)')
          .addChannelOption((o) =>
            o
              .setName('destino')
              .setDescription('Categoria ou canal de texto do atendimento')
              .setRequired(true)
              .addChannelTypes(ChannelType.GuildCategory, ChannelType.GuildText, ChannelType.GuildAnnouncement),
          ),
      ),

    async executar(interaction, { db, client }) {
      const sub = interaction.options.getSubcommand();

      if (sub === 'status') {
        const guildId = interaction.guildId;
        const contar = (tabela) =>
          db.prepare(`SELECT COUNT(*) AS total FROM ${tabela} WHERE guild_id = ?`).get(String(guildId)).total;
        const memoria = Math.round(process.memoryUsage().rss / 1024 / 1024);
        const horas = (process.uptime() / 3600).toFixed(1);

        return responderPrivado(interaction, {
          embeds: [
            embed('🤖 Status do bot', 'Tudo certo por aqui.', {
              cor: config.CORES.sucesso,
              campos: [
                { name: 'Latência', value: `${Math.round(client.ws.ping)} ms`, inline: true },
                { name: 'Online há', value: `${horas}h`, inline: true },
                { name: 'Memória', value: `${memoria} MB`, inline: true },
                { name: 'Usuários', value: String(contar('usuarios')), inline: true },
                { name: 'Partidas', value: String(contar('partidas')), inline: true },
                { name: 'Painéis', value: `${contar('paineis')}/15`, inline: true },
                { name: 'Banco', value: `\`${config.NOME_BANCO}\``, inline: true },
                { name: 'Node.js', value: process.version, inline: true },
                { name: 'Servidores', value: String(client.guilds.cache.size), inline: true },
              ],
              rodape: 'ORG Royal AP',
            }),
          ],
        });
      }

      if (!(await exigirAdmin(interaction))) return;

      if (sub === 'setlog') {
        const canal = interaction.options.getChannel('canal');
        definirConfig(db, interaction.guildId, 'canal_logs', canal.id);
        return responderPrivado(interaction, { content: `✅ Canal de logs: ${canal}.` });
      }

      if (sub === 'setticket') {
        const destino = interaction.options.getChannel('destino');
        definirConfig(db, interaction.guildId, 'destino_tickets', destino.id);
        const eCategoria = destino.type === ChannelType.GuildCategory;
        return responderPrivado(interaction, {
          embeds: [
            embedSucesso(
              `Tickets configurados para **${destino.name}** (${eCategoria ? 'categoria' : 'canal de texto'}).\n` +
                (eCategoria
                  ? 'Os novos tickets são criados dentro dessa categoria.'
                  : 'Os novos tickets são criados na mesma categoria desse canal e o link aparece nele.'),
            ),
          ],
        });
      }

      const categoria = interaction.options.getChannel('categoria');
      definirConfig(db, interaction.guildId, 'categoria_filas', categoria.id);
      return responderPrivado(interaction, { content: `✅ Salas de AP serão criadas em **${categoria.name}**.` });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('conectar')
      .setDescription('Gerencia conexões/APIs externas usadas pela ORG')
      .addStringOption((opcao) => opcao.setName('nome').setDescription('Nome da integração (ex: webhook_vendas)'))
      .addStringOption((opcao) => opcao.setName('url').setDescription('URL ou token da integração')),

    async executar(interaction, { db }) {
      if (!(await exigirAdmin(interaction))) return;
      const nome = interaction.options.getString('nome');
      const url = interaction.options.getString('url');

      if (!nome) {
        const linhas = db
          .prepare("SELECT chave, valor FROM configuracoes WHERE guild_id = ? AND chave LIKE 'integracao:%'")
          .all(interaction.guildId);
        const corpo = linhas.length
          ? linhas
              .map((linha) => `• **${linha.chave.replace('integracao:', '')}** → \`${linha.valor ? 'configurada' : 'vazia'}\``)
              .join('\n')
          : 'Nenhuma integração cadastrada.\nUse `/conectar nome:webhook_vendas url:https://...`.';
        return responderPrivado(interaction, { embeds: [embed('🔌 Integrações', corpo)] });
      }

      if (!url) {
        return responderPrivado(interaction, {
          content: `**${nome}**: \`${obterConfig(db, interaction.guildId, `integracao:${nome}`, 'não configurada')}\``,
        });
      }

      definirConfig(db, interaction.guildId, `integracao:${nome}`, url);
      return responderPrivado(interaction, { embeds: [embedSucesso(`Integração **${nome}** salva.`)] });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('desconectar')
      .setDescription('Remove uma integração/API cadastrada')
      .addStringOption((opcao) => opcao.setName('nome').setDescription('Nome da integração').setRequired(true)),

    async executar(interaction, { db }) {
      if (!(await exigirAdmin(interaction))) return;
      const nome = interaction.options.getString('nome');
      const info = db
        .prepare('DELETE FROM configuracoes WHERE guild_id = ? AND chave = ?')
        .run(interaction.guildId, `integracao:${nome}`);
      return responderPrivado(interaction, {
        content: info.changes ? `🔌 Integração **${nome}** removida.` : `Não achei a integração **${nome}**.`,
      });
    },
  },

  {
    data: new SlashCommandBuilder().setName('ssmob').setDescription('Regras e checklist de mobile (anti-trapaça)'),

    async executar(interaction) {
      return responderPrivado(interaction, {
        embeds: [
          embed(
            '📱 Verificação · Mobile',
            [
              '**Obrigatório no AP mobile:**',
              '• Jogar no celular, sem emulador ou controle externo.',
              '• Gravar a tela do AP inteiro quando o mediador pedir.',
              '• Print do placar final enviado na sala do AP.',
              '• Estar no mesmo servidor/região combinada (Brasil).',
              '',
              '_Suspeita de emulador = W.O. imediato, com print anexado no ticket._',
            ].join('\n'),
            { cor: config.CORES.gelo, rodape: 'ORG Royal AP' },
          ),
        ],
      });
    },
  },

  {
    data: new SlashCommandBuilder().setName('ssemu').setDescription('Regras e checklist de emulador'),

    async executar(interaction) {
      return responderPrivado(interaction, {
        embeds: [
          embed(
            '🖥️ Verificação · Emulador',
            [
              '**Obrigatório no AP emu:**',
              '• Emulador permitido: apenas os liberados pela ORG (BlueStacks 5 / LDPlayer 9).',
              '• Print da configuração do emulador (CPU, RAM, resolução) antes da sala.',
              '• Gravação de tela do AP inteiro, sem cortes.',
              '• Teclas mapeadas devem aparecer na gravação.',
              '',
              '_Macro, script ou tecla automática = banimento da ORG._',
            ].join('\n'),
            { cor: config.CORES.principal, rodape: 'ORG Royal AP' },
          ),
        ],
      });
    },
  },

  {
    data: new SlashCommandBuilder().setName('temu').setDescription('Ferramentas rápidas para jogadores de emulador'),

    async executar(interaction) {
      const botoes = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ap:aux').setLabel('Falar com a staff').setEmoji('🎫').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('ap:como').setLabel('Como funciona o AP').setEmoji('❓').setStyle(ButtonStyle.Secondary),
      );
      return responderPrivado(interaction, {
        embeds: [
          embed(
            '🧰 Ferramentas · Emulador',
            [
              '**Antes de entrar na fila emu:**',
              '1. Teste o ping: `Configurações → Rede → Ping` no emulador.',
              '2. Resolução recomendada: 1280x720 (60 FPS).',
              '3. Feche macros/scripts e reinicie o emulador.',
              '4. Deixe a gravação pronta antes do AP começar.',
              '',
              '**Travou no meio do AP?** Abra um ticket imediatamente com print — sem print, vale W.O.',
            ].join('\n'),
            { cor: config.CORES.neutro, rodape: 'ORG Royal AP' },
          ),
        ],
        components: [botoes],
      });
    },
  },
];

module.exports = { comandos };
